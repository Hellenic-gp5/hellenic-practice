export class LoginModel
{
    public username : string;
    public password : string;
    public role : string;
}